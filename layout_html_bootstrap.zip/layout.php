<html>
<head>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div id="wrapper">
    <div class="row">
        <div class="col-md-12 border" id="header">
            <h1>This is header</h1>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 border">
            <ul class="nav">

                <li class="nav-item"><a href="#" class="nav-link">home</a></li>
                <li class="nav-item"><a href="#" class="nav-link">danhsach</a></li>
                <li class="nav-item"><a href="#" class="nav-link">them</a></li>
            </ul>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3 border">
            <ul class="nav flex-column">
                <li class="nav-item"><a href="#" class="nav-link">danh sach</a></li>
                <li class="nav-item"><a href="#" class="nav-link">sua</a></li>
                <li class="nav-item"><a href="#" class="nav-link">them moi</a></li>
            </ul>
        </div>
        <div class="col-md-6 border">body</div>
        <div class="col-md-3 border">
            block phai
        </div>
    </div>

    <div class="row">
        <div class="col-md-12 border">@2018 copyright mysite</div>
    </div>
</div>
</body>
</html>